

# This file contains information about urls

 #imports for this file
from django.contrib import admin
from django.urls import path
from django.conf.urls import url,include

urlpatterns = [

    # This is default URL included by Django
    path('admin/', admin.site.urls),

    # This URL is related to our project and is similar as app name:
    #Our home page is http://127.0.0.1:8000/accounts/
    #Here accounts is our home page or main page
    url(r'^accounts/', include('accounts.urls'))
]
