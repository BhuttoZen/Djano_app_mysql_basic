
"""
This file contains information about data that we have in our DATABASES
as we have APPLE,BANANA,ORANGE and PEACH in our database so we need to create
this for each table that we want to access in our django app.
"""



from django.db import models


class Apple(models.Model):
    type = models.CharField(db_column='Type', max_length=100)  # Field name made lowercase.
    price = models.IntegerField(db_column='Price')  # Field name made lowercase.
    quantity = models.IntegerField(db_column='Quantity')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'apple'


class Banana(models.Model):
    type = models.CharField(db_column='Type', max_length=100)  # Field name made lowercase.
    price = models.IntegerField(db_column='Price')  # Field name made lowercase.
    quantity = models.IntegerField(db_column='Quantity')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'banana'


class Orange(models.Model):
    type = models.CharField(db_column='Type', max_length=200)  # Field name made lowercase.
    price = models.IntegerField(db_column='Price')  # Field name made lowercase.
    quantity = models.IntegerField(db_column='Quantity')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'orange'


class Peach(models.Model):
    type = models.CharField(db_column='Type', max_length=200)  # Field name made lowercase.
    price = models.IntegerField(db_column='Price')  # Field name made lowercase.
    quantity = models.IntegerField(db_column='Quantity')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'peach'
