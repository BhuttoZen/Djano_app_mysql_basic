from django.conf.urls import url
from .import views

# This is view as implemented in views.py file
#We add every view in url here we have only HomeView so that is added
urlpatterns=[
    url(r'^$', views.HomeView.as_view()),
]
