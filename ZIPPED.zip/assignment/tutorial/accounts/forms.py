from django import forms

"""
This is the form that we use for choice dropdown menu
It is created using Django forms
"""
class HomeForm(forms.Form):
    fruits = forms.ChoiceField(choices=[('banana','Banana'),('apple','Apple'),('peach','Peach'),('orange','Orange') ])
