
#This import is for VIEW which is in this case TemplateView
from django.views.generic import TemplateView
from django.shortcuts import render,redirect

# These imports are from our models.py as defined in our database
from accounts.models import Apple,Banana,Orange,Peach
#This import is from froms.py as our form class is HomeForm
from accounts.forms import HomeForm

#Implementation of View Class

class HomeView(TemplateView):
    #Html page saved in tutorial\accounts\template folder as our home page called template_name
    template_name= 'home.html'

    #When we load page for first time it is loaded using get function
    def get(self,request):
        #form= HomeForm() loads form on home.html page
        form = HomeForm()
        args1 = { 'form': form, }
        #Render is used to acctually load all data on page 'home.html'
        #This function means on get request load 'home.html' with data args1 as form
        return render(request,'home.html',args1)


# This is used when we make selecion from drop down menu.
    def post(self,request):

        #THIS IS POST METHOD GET VALUE FROM SELECTION
        form = HomeForm(request.POST)
        if form.is_valid():
            text = form.cleaned_data['fruits'] # gets value when we select one from dropdown menu i.e. apple.banana etc.
            form=HomeForm()

            #After selection of value we dislply that table using objects.all() command
            if (text=='banana'):
                post = Banana.objects.all()
            elif (text == 'apple'):
                post = Apple.objects.all()
            elif (text == 'orange'):
                post = Orange.objects.all()
            elif (text == 'peach'):
                post = Peach.objects.all()
            else:
                return redirect('http://127.0.0.1:8000')

        args = { 'form':form,'text':text, 'posts1':post }
        return render(request,'home.html',args)
